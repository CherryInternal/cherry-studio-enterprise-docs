# 常见问题处理

这份文档用于部署失败、服务异常、用户反馈无法访问时的排障。

优先根据实际路径选择对应章节：

- Docker 部署问题
- Helm / Kubernetes 部署问题

---

## Docker 路径

### Docker 拉取镜像失败

- 国内服务器优先切换镜像源
- 检查网络连接：`ping docker.1ms.run`
- 检查 Docker Hub 是否可访问
- 手动配置 Docker 镜像加速

### 数据库连接失败

- 检查 PostgreSQL 容器状态：`docker compose logs postgres`
- 确认 `.env` 中密码一致
- 检查 PostgreSQL 健康检查：`docker compose exec postgres pg_isready`

### 端口被占用

- 检查占用：`sudo lsof -i :<port>` 或 `sudo ss -tlnp | grep <port>`
- 修改 `docker-compose.yml` 中的端口映射

### 服务启动后无法访问

- 检查服务状态：`docker compose ps`
- 检查 API：`curl http://localhost:3670/`
- 检查管理后台：`curl http://localhost:3680/`
- 检查防火墙和安全组
- 检查 Nginx 配置（如果使用）
- 检查容器日志：`docker compose logs api`

### 用户填错 API_URL

常见错误：

- 写成 `http://<IP>`，漏掉端口
- 写成内网地址，但客户端在外网使用
- 写成还没解析好的域名

处理方式：

- 如果是 IP 访问，必须带端口：`http://<IP>:3670`
- 如果是域名访问，确认 DNS 已解析且反向代理已配置

---

## Helm / Kubernetes 路径

### kubectl 或 helm 不可用

先检查：

```bash
kubectl version --client
helm version
```

如果命令都不可用，不要继续安装，先补环境。

### Pod 一直是 ContainerCreating / Pending

检查：

```bash
kubectl get pods -A
kubectl describe pod <pod-name> -n <namespace>
kubectl get events -n <namespace> --sort-by=.lastTimestamp
```

常见原因：

- 镜像拉取失败
- PVC 未绑定
- 节点资源不足
- CNI / 集群系统组件未就绪

### Helm 默认版本过旧

官方 Helm Chart 主分支当前默认仍会落到：

- `appVersion: v0.1.3`
- `app.replicaCount: 2`
- `app.autoscaling.enabled: true`

如果用户没有在 `values-custom.yaml` 中覆盖这些值，可能出现：

- 部署到旧镜像版本
- 副本数不符合单实例要求
- autoscaling 打开后与单实例预期不一致

建议显式覆盖：

```yaml
app:
  replicaCount: 1
  image:
    tag: v0.4.10
  autoscaling:
    enabled: false
```

### PVC 一直 Pending

检查：

```bash
kubectl get sc
kubectl get pvc -n <namespace>
kubectl describe pvc <pvc-name> -n <namespace>
```

常见原因：

- 没有默认 `StorageClass`
- provisioner 没有正常运行
- helper pod 镜像拉取失败
- 节点本地存储路径或权限异常

### 系统组件拉镜像失败

尤其在国内环境下，K3s / Kubernetes 默认镜像可能拉取超时。

重点检查：

- `docker.io` 是否可访问
- 是否需要配置镜像加速
- 集群使用的 container runtime 是否已经配置 registry mirror

### PostgreSQL 连接失败

检查：

```bash
kubectl logs -n <namespace> deployment/<release-name>-api
```

重点确认：

- `DB_HOST`
- `DB_PORT`
- `DB_USERNAME`
- `DB_PASSWORD`
- `DB_NAME`
- `DB_SSL`

### API_URL 填错

Helm 路径里，`API_URL` 一定要是最终用户实际访问的地址。

常见错误：

- Ingress 已启用，但 `API_URL` 还写成测试 NodePort
- NodePort 部署，却写成域名
- 域名未解析或 TLS 未完成时提前写成 `https://...`

### `/health` 返回 404

不要立刻判断部署失败。

先检查：

```bash
curl -i http://<API地址>/
kubectl get pods -n <namespace>
```

如果：

- Pod 是 `Running`
- Readiness 是 `Ready`
- 根路径 `/` 返回 `200`

那说明服务已经启动，只是当前版本未暴露 `/health`。

---

## 通用排障顺序

无论 Docker 还是 Helm，建议按这个顺序排查：

1. **先看资源状态**
2. **再看日志**
3. **再看网络**
4. **最后看用户填的地址和密码**

不要一开始就怀疑应用本身，很多问题其实是：

- 地址填错
- 端口没开
- 镜像没拉下来
- 数据库没通
- 存储没绑定
