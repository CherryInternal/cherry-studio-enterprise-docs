# Docker 路径

这份文档用于 **单机 / 普通服务器 / 用户不熟悉 Kubernetes** 的部署场景。

如果用户没有现成 Kubernetes 集群，或者只是希望尽快把 Cherry Studio Enterprise 跑起来，默认使用这条路径。

---

## 核心信息速查

| 项目 | 值 |
|------|------|
| **API 服务端口** | `3670` |
| **管理后台端口** | `3680` |
| **默认管理员** | 用户名 `admin`，密码 `secret` |
| **数据目录** | 容器内 `/app/data`（挂载到宿主机） |
| **数据库** | PostgreSQL 12+（推荐 15.x） |
| **最低配置** | 2 核 CPU / 4GB 内存 / 20GB 存储 |
| **推荐配置** | 4 核 CPU / 8GB 内存 / 50GB 存储 |

### Docker 镜像源

| 环境 | 镜像地址 |
|------|---------|
| **国际** | `cherrystudio/cherry-studio-enterprise-api:latest` |
| **国内加速** | `docker.1ms.run/cherrystudio/cherry-studio-enterprise-api:latest` |
| **GitCode 国内** | 从 `https://gitcode.com/CherryHQ/cherry-studio-enterprise-docker` 获取 |

> 优先尝试国内加速源。如果拉取失败，切换到另一个源。

---

## 部署流程总览

```text
Phase 1: 信息收集（问用户）
    ↓
Phase 2: 环境准备（安装 Docker、配置镜像加速）
    ↓
Phase 3: 部署应用（PostgreSQL + Cherry Studio Enterprise）
    ↓
Phase 4: 网络配置（防火墙检测、Nginx 反向代理、域名/SSL 可选）
    ↓
Phase 5: 管理后台初始化引导
    ↓
Phase 6: 客户端连接引导
```

---

## Phase 1: 信息收集

**在做任何操作之前，先逐步收集以下信息。每次只问 1-2 个问题，不要一次性问完。**

### 必须收集的信息

1. **执行方式**：
   - `ssh` — 你通过 SSH 直接连接到服务器执行命令
   - `script` — 你生成命令脚本，用户自己复制到服务器执行
   - 如果用户不确定，推荐 `ssh` 模式

2. **服务器信息**（ssh 模式下）：
   - IP 地址
   - SSH 端口（默认 22）
   - 登录用户名
   - 认证方式：密码 或 SSH 密钥路径

3. **服务器操作系统**：
   - 如果 ssh 模式，连上后自动检测
   - 如果 script 模式，需要询问：Ubuntu/Debian、CentOS/RHEL、macOS

4. **API 访问地址**（⚠️ 最容易出错）：
   - 如果有域名并且打算配 Nginx 反向代理：填域名，如 `https://api.example.com`
   - 如果没有域名，直接用 IP 访问：**必须带端口号**，填 `http://<服务器IP>:3670`
   - **绝对不能填** `http://<IP>` 不带端口

5. **网络环境**：
   - 服务器在国内还是国外？决定镜像源和加速配置

### 可选信息

- 数据库：默认随应用一起部署（Docker Compose 内置 PostgreSQL）
- JWT Secret：自动生成
- 管理后台名称：默认 `Cherry Studio Enterprise`
- SSL 证书：如果用户提供了域名，再问要不要配 HTTPS

---

## Phase 2: 环境准备

### 2.1 连接服务器（ssh 模式）

```bash
ssh -o StrictHostKeyChecking=accept-new <user>@<ip> -p <port>
```

如果用密钥：

```bash
ssh -o StrictHostKeyChecking=accept-new -i <key_path> <user>@<ip> -p <port>
```

### 2.2 检测操作系统

```bash
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "OS: $ID $VERSION_ID"
elif [[ "$(uname)" == "Darwin" ]]; then
    echo "OS: macOS $(sw_vers -productVersion)"
fi
```

### 2.3 安装 Docker

**Ubuntu / Debian：**

```bash
sudo apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/$(. /etc/os-release && echo "$ID")/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$(. /etc/os-release && echo "$ID") $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

**CentOS / RHEL：**

```bash
sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine 2>/dev/null
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl start docker
sudo systemctl enable docker
```

**macOS：**

```bash
if ! command -v brew &>/dev/null; then
    echo "请先安装 Homebrew: https://brew.sh"
    exit 1
fi

brew install --cask docker
echo "⚠️ 请手动打开 Docker Desktop，等待 Docker 引擎启动后继续"
```

### 2.4 配置 Docker 镜像加速（国内服务器）

```bash
sudo mkdir -p /etc/docker
cat <<'EOF' | sudo tee /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://docker.1ms.run"
  ]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

### 2.5 验证 Docker

```bash
docker --version
docker compose version
docker run --rm hello-world
```

---

## Phase 3: 部署应用

### 3.1 创建项目目录

```bash
sudo mkdir -p /opt/cherry-studio-enterprise
cd /opt/cherry-studio-enterprise
```

macOS 下：

```bash
mkdir -p ~/cherry-studio-enterprise
cd ~/cherry-studio-enterprise
```

### 3.2 生成环境变量

```bash
JWT_SECRET=$(openssl rand -base64 32)
POSTGRES_PASSWORD=$(openssl rand -base64 16)

cat <<EOF > .env
# === Cherry Studio Enterprise 配置 ===
API_URL=<用户提供的地址>

# JWT 密钥（已自动生成，请勿泄露）
JWT_SECRET=${JWT_SECRET}

# 数据库密码（已自动生成）
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
EOF

echo "✅ .env 文件已生成"
cat .env
```

### 3.3 生成 docker-compose.yml

如果用户希望直接复制现成模板，可参考：

- [templates/docker-compose.yml.tmpl](templates/docker-compose.yml.tmpl)

```yaml
services:
  postgres:
    image: postgres:15-alpine
    container_name: cherry-studio-enterprise-postgres
    environment:
      POSTGRES_USER: cherry-studio-enterprise
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: cherry-studio-enterprise
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped
    healthcheck:
      test: ['CMD-SHELL', 'pg_isready -U cherry-studio-enterprise']
      interval: 10s
      timeout: 5s
      retries: 5

  api:
    image: <根据国内/国外选择镜像>
    container_name: cherry-studio-enterprise
    depends_on:
      postgres:
        condition: service_healthy
    ports:
      - '3670:3670'
      - '3680:3680'
    environment:
      - API_URL=${API_URL}
      - ADMIN_APP_NAME=Cherry Studio Enterprise
      - JWT_SECRET=${JWT_SECRET}
      - DB_TYPE=postgres
      - DB_HOST=postgres
      - DB_PORT=5432
      - DB_USERNAME=cherry-studio-enterprise
      - DB_PASSWORD=${POSTGRES_PASSWORD}
      - DB_NAME=cherry-studio-enterprise
      - DB_SSL=false
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ['CMD', 'wget', '--quiet', '--tries=1', '--spider', 'http://localhost:3670/']
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  postgres_data:
    driver: local
```

**镜像选择逻辑：**

- 国内服务器 → `docker.1ms.run/cherrystudio/cherry-studio-enterprise-api:latest`
- 国外服务器 → `cherrystudio/cherry-studio-enterprise-api:latest`
- 如果拉取失败 → 提示用户尝试 GitCode 源

### 3.4 启动服务

```bash
mkdir -p data logs
sudo chown -R 1000:1000 data

docker compose pull
docker compose up -d

echo "等待服务启动..."
sleep 15

docker compose ps
curl -s http://localhost:3670/ && echo " ✅ API 服务正常" || echo " ❌ API 服务未就绪，请检查日志: docker compose logs api"
```

### 3.5 验证部署

```bash
docker compose ps
docker compose logs --tail=50 api
docker compose logs --tail=20 postgres
```

---

## Phase 4: 网络配置

### 4.1 防火墙检测

**只做检测和提示，不强制修改。**

```bash
if command -v ufw &>/dev/null; then
    echo "检测到 ufw 防火墙:"
    sudo ufw status
elif command -v firewall-cmd &>/dev/null; then
    echo "检测到 firewalld 防火墙:"
    sudo firewall-cmd --state
    sudo firewall-cmd --list-all
else
    echo "未检测到本地防火墙"
fi
```

提醒用户开放端口：

- `3670`
- `3680`
- `80`
- `443`

### 4.2 安装 Nginx（如果用户选择配置域名）

**Ubuntu / Debian：**

```bash
sudo apt-get install -y nginx
sudo systemctl enable nginx
```

**CentOS / RHEL：**

```bash
sudo yum install -y epel-release
sudo yum install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

**macOS：**

```bash
brew install nginx
brew services start nginx
```

### 4.3 配置 Nginx 反向代理

如果用户提供了域名：

```nginx
server {
    listen 80;
    server_name <API_DOMAIN>;

    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:3670;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }
}

server {
    listen 80;
    server_name <ADMIN_DOMAIN>;

    location / {
        proxy_pass http://localhost:3680;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 4.4 SSL 证书（可选）

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d <API_DOMAIN> -d <ADMIN_DOMAIN> --non-interactive --agree-tos -m <用户邮箱>
sudo certbot renew --dry-run
```

---

## Phase 5: 管理后台初始化引导

### 5.1 访问管理后台

```text
管理后台地址：http://<服务器IP>:3680（或 https://admin.example.com）
默认账号：admin
默认密码：secret

⚠️ 请登录后立即修改默认密码！
```

### 5.2 引导配置步骤

告诉用户按以下顺序操作：

1. 修改管理员密码
2. 添加 AI 服务商
3. 创建用户组
4. 创建用户
5. （可选）激活授权

### 5.3 验证管理后台可用

```bash
curl -s http://localhost:3680 | head -5 && echo "✅ 管理后台可访问" || echo "❌ 管理后台无法访问"
```

---

## Phase 6: 客户端连接引导

### 6.1 下载客户端

告诉用户：

> Cherry Studio 桌面客户端支持 Windows、macOS 和 Linux。  
> 请从管理员提供的下载地址获取客户端安装包。

### 6.2 配置客户端连接

告诉用户在客户端中：

1. 打开客户端设置
2. 找到「企业版服务器」或「API 服务器」配置项
3. 填入 API 地址：`http://<服务器IP>:3670`（或 `https://api.example.com`）
4. 使用管理员分配的账号密码登录
5. 选择模型并发送第一条消息测试

### 6.3 连接测试

如果用户反馈客户端连不上，排查清单：

- 服务是否运行：`docker compose ps`
- API 是否响应：`curl http://<IP>:3670/`
- 防火墙/安全组是否开放 3670 端口
- 如果用了域名，DNS 是否解析正确
- 如果用了 Nginx，检查配置：`sudo nginx -t`
