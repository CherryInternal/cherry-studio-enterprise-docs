# Helm 路径

这份文档用于 **已经有 Kubernetes 集群**，或者用户明确要求 **Helm 部署** 的场景。

如果用户没有现成 Kubernetes 集群，或者不熟悉 `kubectl` / `helm`，不要优先走这条路径，默认改走 Docker。

---

## 核心信息速查

| 项目 | 值 |
|------|------|
| **最低 Kubernetes 版本** | `1.16+` |
| **最低 Helm 版本** | `3.0+` |
| **数据库** | PostgreSQL 12+（推荐 15.x） |
| **存储要求** | 集群必须支持 PVC，最好已有默认 StorageClass |
| **API 服务端口** | `3670` |
| **管理后台端口** | `3680` |
| **推荐资源** | 4 核 CPU / 8GB 内存 / 50GB 存储 |

### 官方参考

- 官方文档仓库：`https://github.com/CherryInternal/cherry-studio-enterprise-docs`
- 官方 Helm Chart：`https://github.com/CherryInternal/cherry-studio-enterprise-helm`

### 当前版本提醒

- 官方 Helm Chart 主分支当前仍是 `appVersion: v0.1.3`
- 如果 `values-custom.yaml` 里**不显式指定** `app.image.tag`，Chart 会默认使用 `v0.1.3`
- 当前镜像仓库可见的较新稳定版本已经到 `v0.4.10`
- 因此部署时建议**显式覆盖**：
  - `app.image.tag: v0.4.10`
  - `app.replicaCount: 1`
  - `app.autoscaling.enabled: false`

> 上面这组值是为了避开官方 Chart 的旧默认值。尤其是 `replicaCount: 2` 和默认开启 autoscaling，单实例部署时都不合适。

---

## 部署流程总览

```text
Phase 1: 信息收集（确认集群和访问方式）
    ↓
Phase 2: Kubernetes 环境检查（kubectl / helm / storage / namespace）
    ↓
Phase 3: 数据库与配置准备（PostgreSQL / Secret / values）
    ↓
Phase 4: 安装或升级 Helm Release
    ↓
Phase 5: 暴露服务（Ingress / NodePort / LoadBalancer）
    ↓
Phase 6: 验证与交付（Pod / PVC / API / Admin）
```

---

## Phase 1: 信息收集

### 必须收集的信息

1. **集群接入方式**
   - 你是否能直接执行 `kubectl`？
   - 是用户本地已有 `kubeconfig`，还是你通过 SSH 到某台跳板机/控制节点执行？

2. **目标命名空间**
   - 如果用户没提供，可默认 `cherry-studio`

3. **服务暴露方式**
   - `Ingress`
   - `NodePort`
   - `LoadBalancer`

4. **API 最终访问地址**
   - 如果用 Ingress：`https://api.example.com`
   - 如果用 NodePort：`http://<NodeIP>:<NodePort>`
   - 这个值最终要写进 `API_URL`

5. **PostgreSQL 信息**
   - `DB_HOST`
   - `DB_PORT`
   - `DB_USERNAME`
   - `DB_PASSWORD`
   - `DB_NAME`
   - 是否启用 SSL

### 可选信息

- Release 名称：默认 `cherry-studio-enterprise`
- Storage 大小：默认 `10Gi`，建议 `20Gi`
- 管理后台名称：默认 `Cherry Studio Enterprise`
- 是否需要 Ingress TLS

---

## Phase 2: Kubernetes 环境检查

**这一步非常关键。条件不满足时，不要直接执行 `helm install`。**

### 2.1 检查 kubectl 和 helm

```bash
kubectl version --client
helm version
```

### 2.2 检查集群

```bash
kubectl get nodes -o wide
kubectl get ns
```

### 2.3 检查默认 StorageClass

```bash
kubectl get sc
```

如果没有默认 `StorageClass`，要提前告诉用户：

- PVC 可能无法自动绑定
- Helm 安装很可能卡住

### 2.4 检查镜像拉取能力

如果集群在国内或网络较差，提前提醒：

- 系统组件和业务镜像都可能因为 Docker Hub 拉取慢而失败
- 必要时需要配置镜像加速

---

## Phase 3: 数据库与配置准备

### 3.1 PostgreSQL 原则

Helm Chart **不会部署** PostgreSQL 容器，必须提供**外部** PostgreSQL 实例。

> ⚠️ **重要警告**：官方 `values.yaml` 里默认的 `DB_HOST` / `DB_USERNAME` / `DB_PASSWORD` / `JWT_SECRET` 是**供应商测试环境的凭据**（指向 `1panel.cherry-ai.com`）。
>
> 如果 `values-custom.yaml` 漏掉任意一个 DB_* 或 JWT_SECRET 字段，Helm 会 merge 默认值，Pod 会**静默连到供应商测试库**，造成数据写错库或泄漏。

因此必须**完整覆盖**以下全部字段，缺一不可：

- `DB_HOST` / `DB_PORT` / `DB_USERNAME` / `DB_PASSWORD` / `DB_NAME` / `DB_TYPE` / `DB_SSL`
- `JWT_SECRET`

如果用户没有现成 PostgreSQL，可明确告诉用户：

- 先准备数据库
- 或切回 Docker 路径，用单机内置 PostgreSQL

### 3.2 生成 JWT Secret

```bash
openssl rand -base64 32
```

### 3.3 准备 values-custom.yaml

如果用户希望直接复制现成模板，可参考：

- [templates/values-custom.yaml.tmpl](templates/values-custom.yaml.tmpl)

```yaml
app:
  replicaCount: 1

  image:
    tag: v0.4.10

  autoscaling:
    enabled: false

  env:
    API_URL: https://api.example.com
    JWT_SECRET: 'your-secure-jwt-secret'
    DB_HOST: your-postgres-host
    DB_PORT: 5432
    DB_USERNAME: your-username
    DB_PASSWORD: your-password
    DB_NAME: your-database
    DB_TYPE: postgres
    DB_SSL: false

  persistence:
    enabled: true
    size: 20Gi

  api:
    service:
      type: ClusterIP
      port: 3670
      targetPort: 3670
    ingress:
      enabled: true
      annotations:
        nginx.ingress.kubernetes.io/proxy-body-size: '20m'
      hosts:
        - host: api.example.com
          paths:
            - path: /
              pathType: ImplementationSpecific

  admin:
    service:
      type: ClusterIP
      port: 3680
      targetPort: 3680
    ingress:
      enabled: true
      annotations:
        nginx.ingress.kubernetes.io/proxy-body-size: '20m'
      hosts:
        - host: admin.example.com
          paths:
            - path: /
              pathType: ImplementationSpecific
```

### 3.4 什么时候用 NodePort

如果用户只是测试，或者没有 Ingress Controller，可改成：

```yaml
app:
  api:
    service:
      type: NodePort
  admin:
    service:
      type: NodePort
```

### 3.5 敏感信息的明文风险（重要）

当前 Chart 把 `app.env` 下所有字段原样渲染为 Deployment 的 `env.value`，**没有任何 Secret 模板**。这意味着：

- `JWT_SECRET`、`DB_PASSWORD` 会**明文**出现在：
  - `kubectl describe deploy` 输出
  - `kubectl get deploy -o yaml`
  - etcd 存储
  - 任何有 `get/list deployments` 权限的账号都能看到

生产环境建议：

- 收紧 namespace RBAC，不给无关账号 `get deployments` / `describe pod` 权限
- 或自行 patch Chart：把敏感字段改为 `envFrom.secretRef`，先 `kubectl create secret generic cherry-secrets --from-literal=DB_PASSWORD=xxx --from-literal=JWT_SECRET=xxx`
- 关注上游后续是否原生支持 Secret 注入

### 3.6 Ingress TLS 示例

若需要 HTTPS，且集群已安装 `cert-manager`：

```yaml
app:
  api:
    ingress:
      annotations:
        nginx.ingress.kubernetes.io/proxy-body-size: '20m'
        cert-manager.io/cluster-issuer: letsencrypt-prod
      hosts:
        - host: api.example.com
          paths:
            - path: /
              pathType: ImplementationSpecific
      tls:
        - secretName: cherry-api-tls
          hosts:
            - api.example.com
```

若不使用 cert-manager，需要预先 `kubectl create secret tls cherry-api-tls --cert=... --key=...`，然后只保留 `tls:` 块。

### 3.7 私有 registry / 国内镜像加速

默认镜像 `cherrystudio/cherry-studio-enterprise-api` 在国内拉取可能失败。可在 values 中覆盖：

```yaml
app:
  image:
    repository: your-registry.example.com/cherry-studio-enterprise-api
    tag: v0.4.10

imagePullSecrets:
  - name: regcred
```

`regcred` 需要预先创建：

```bash
kubectl -n cherry-studio create secret docker-registry regcred \
  --docker-server=your-registry.example.com \
  --docker-username=xxx \
  --docker-password=xxx
```

### 3.8 管理后台品牌化（可选）

默认 values.yaml 还有几个 admin 端的环境变量，如果需要改品牌可一并覆盖：

```yaml
app:
  env:
    ADMIN_APP_NAME: Cherry Studio Enterprise
    ADMIN_APP_LOGO_URL: https://your-cdn.example.com/logo.webp
    ADMIN_BASE_PATH: /
```

> 注意：默认 `ADMIN_APP_LOGO_URL` 指向外网 gitcode，**离线/内网环境**下 logo 会加载失败，建议换成内部 CDN 或 data URI。

---

## Phase 4: 安装或升级 Helm Release

### 4.1 获取 Chart

建议**锁定到明确的 tag**，不要直接用 main 分支 HEAD（main 上的 Chart `version` / `appVersion` 随时可能变）：

```bash
git clone --branch v0.1.2 https://github.com/CherryInternal/cherry-studio-enterprise-helm
cd cherry-studio-enterprise-helm
```

或者下载 release zip：

```bash
wget https://github.com/CherryInternal/cherry-studio-enterprise-helm/archive/v0.1.2.zip
unzip v0.1.2.zip
cd cherry-studio-enterprise-helm-0.1.2
```

### 4.2 安装

推荐用 values 文件方式（可追溯、便于 GitOps）：

```bash
helm install cherry-studio-enterprise ./helm \
  --namespace cherry-studio \
  --create-namespace \
  -f values-custom.yaml
```

如果只是临时覆盖单个字段、不想改文件，可用 `--set`：

```bash
helm install cherry-studio-enterprise ./helm \
  --namespace cherry-studio \
  --create-namespace \
  -f values-custom.yaml \
  --set app.image.tag=v0.4.10
```

### 4.3 升级

```bash
helm upgrade cherry-studio-enterprise ./helm \
  --namespace cherry-studio \
  -f values-custom.yaml
```

### 4.4 等待资源就绪

```bash
kubectl get pods -n cherry-studio
kubectl get svc -n cherry-studio
kubectl get pvc -n cherry-studio
helm status cherry-studio-enterprise -n cherry-studio
```

---

## Phase 5: 暴露服务

### 5.1 Ingress

适合正式环境。

前提：

- 已安装 Ingress Controller
- 域名已解析
- 如需 HTTPS，TLS 已准备

### 5.2 NodePort

适合测试环境。

获取地址：

```bash
kubectl get svc -n cherry-studio
kubectl get nodes -o wide
```

最终访问地址示例：

- API：`http://<NodeIP>:<NodePort>`
- Admin：`http://<NodeIP>:<AdminNodePort>`

### 5.3 LoadBalancer

适合有云负载均衡能力的集群。

```bash
kubectl get svc -n cherry-studio
```

如果服务拿到了外部 IP，再把它用于最终访问地址。

---

## Phase 6: 验证与交付

### 6.1 检查资源状态

```bash
kubectl get pods,svc,pvc -n cherry-studio -o wide
helm status cherry-studio-enterprise -n cherry-studio
```

### 6.2 检查 API

优先检查根路径：

```bash
curl -i http://<API地址>/
```

如果当前版本支持，也可以再试：

```bash
curl -i http://<API地址>/health
```

> 注意：不同版本不一定都暴露 `/health`。如果 `/health` 返回 `404`，但 `/` 返回 `200` 且 Pod `Ready`，仍应视为服务已启动。

### 6.3 检查 Admin

```bash
curl -I http://<Admin地址>/
```

### 6.4 交付用户时要说明

- 当前访问地址
- 当前 Release 名称
- 当前 Namespace
- 当前数据库连接方式
- 是否使用 Ingress / NodePort / LoadBalancer
- 后续升级命令

---

## Helm 路径特别提醒

1. **Helm 不是更简单，只是更适合已有 K8s 的客户**
2. **没有 PostgreSQL、没有 StorageClass、没有服务暴露方案时，不要强装**
3. **如果只是先跑起来，优先改走 Docker**
4. **如果 Helm 卡在 Pending / PVC / ContainerCreating，优先查看 [troubleshooting.md](troubleshooting.md)**

---

## 多节点集群额外注意事项

单节点（如单台 Ubuntu）通常不会踩到以下坑，但**多节点集群**要额外留意：

### 存储：RWO + 本地存储 = 调度坑

- Chart 默认 `persistence.accessMode: ReadWriteOnce`
- 如果用的是 `local-path` / `hostPath` 这类**节点本地存储**，PV 绑在哪台节点就只能跑在哪台节点
- Pod 被重新调度到其他节点时，PVC 无法挂载，Pod 会卡 `Pending` 或 `ContainerCreating`

**解决方案（二选一）**：

- 使用**网络存储** StorageClass（NFS、Ceph RBD、云盘 CSI 等），确保任意节点都能挂载
- 或给 Pod 加 `nodeSelector` / `nodeAffinity`，固定到 PV 所在节点

### 副本数与 RWO 的冲突

- `replicaCount: 1` + RWO 没问题
- `replicaCount >= 2` + RWO 会**只有一个 Pod 能启动**，其余卡在 `ContainerCreating`
- 多副本必须配合 RWX（ReadWriteMany）存储，例如 NFS

### Ingress Controller 必须先装好

- 单节点测试常走 NodePort，可以不装 Ingress Controller
- 多节点生产通常走 Ingress，需要提前安装（`ingress-nginx` / `traefik` 等），并确保域名解析到对应入口

### 镜像在所有节点都要拉得到

- Pod 可能调度到任意节点，每台节点都需要能访问镜像仓库
- 私有 registry 的 `imagePullSecrets` 要建在目标 namespace 里
- 国内集群建议配置镜像加速或使用内部 registry

### 资源分布

- 数据库、Redis（如有）、API Pod 之间的网络延迟要测一下
- 跨机房/跨可用区部署时，数据库建议就近访问
